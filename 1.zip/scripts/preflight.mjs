import { execFileSync } from 'node:child_process';

const major = Number(process.versions.node.split('.')[0]);
if (major < 20) {
  console.error(`❌ هذا المشروع يحتاج Node.js 20 أو أحدث. الإصدار الحالي: ${process.version}`);
  console.error('في Pterodactyl اختر Docker Image / Egg مبنيًا على Node.js 20 أو 22 ثم أعد التشغيل.');
  process.exit(1);
}

const required = ['ffmpeg', 'yt-dlp'];
for (const command of required) {
  try {
    execFileSync(command, ['--version'], { stdio: 'ignore' });
  } catch {
    console.warn(`⚠️ ${command} غير موجود. أغلب البوت سيعمل، لكن الوظائف التي تعتمد عليه لن تعمل حتى يتم تثبيته.`);
  }
}

console.log(`✅ Node.js ${process.version} مناسب للتشغيل.`);
