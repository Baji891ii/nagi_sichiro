import fs from 'node:fs/promises';
import path from 'node:path';

const root = path.resolve('.');
const commandDir = path.join(root, 'commands');
const files = (await fs.readdir(commandDir, { withFileTypes: true }))
  .filter(x => x.isFile() && x.name.endsWith('.js'))
  .map(x => x.name)
  .sort();

let failed = 0;
for (const file of files) {
  try {
    await import(new URL(`../commands/${file}?doctor=${Date.now()}${Math.random()}`, import.meta.url));
    console.log(`OK  ${file}`);
  } catch (e) {
    failed++;
    console.error(`ERR ${file}: ${e?.message || e}`);
  }
}

const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
const required = Object.keys(pkg.dependencies || {});
const missing = [];
for (const dep of required) {
  try { await import(`${dep}/package.json`, { with: { type: 'json' } }); }
  catch { missing.push(dep); }
}

if (missing.length) {
  console.error(`Missing dependencies: ${missing.join(', ')}`);
  failed++;
}

if (failed) process.exit(1);
console.log(`\nDoctor passed: ${files.length} command files loaded.`);
