# STEAM BOT V2

## المتطلب الأهم

- Node.js **20 أو أحدث**. Node.js 18 غير مدعوم.
- npm
- Python
- FFmpeg (مطلوب لوظائف الوسائط)
- yt-dlp (مطلوب لوظائف الصوت/YouTube)
- اتصال إنترنت

## Pterodactyl

1. اختر Docker Image / Egg يحتوي على Node.js 20 أو 22.
2. ارفع ملفات المشروع.
3. شغّل:

```bash
bash install.sh
```

أو:

```bash
./start.sh
```

`start.sh` يثبت `node_modules` تلقائيًا إذا لم تكن موجودة، ثم يشغّل البوت.

إذا ظهر `ERR_MODULE_NOT_FOUND` بسبب مكتبة من dependencies، لا تشغّل `node index.js` مباشرة؛ استخدم `npm start` أو `./start.sh` بعد التأكد من Node 20+.

## أول تشغيل

إذا لم توجد جلسة WhatsApp، يكون الربط عبر Telegram فقط. أرسل من الحساب المصرّح له:

```text
/pair 201xxxxxxxxx
```

سيتم إرسال Pairing Code إلى نفس محادثة Telegram، بينما يبقى البوت نفسه يعمل على WhatsApp فقط.

لا تحذف مجلد `session` بعد الربط إذا أردت الاحتفاظ بالجلسة.

## Telegram للربط فقط

يمكن تغيير بيانات Telegram عبر المتغيرات التالية:

```bash
export TELEGRAM_BOT_TOKEN=...
export TELEGRAM_ADMIN_ID=...
```

## ملاحظات

لا حاجة لإدخال رقم الهاتف من الطرفية؛ رقم WhatsApp يُرسل عبر Telegram باستخدام `/pair`.
