export default {
  name: 'حالة',
  aliases: ['health', 'status'],
  category: 'عام',
  requiredRole: 'user',
  async execute({ message }) {
    return message.reply('✅ البوت يعمل بشكل طبيعي.\n🟢 WhatsApp: متصل بالأوامر\n🟢 Command Loader: يعمل');
  }
};
